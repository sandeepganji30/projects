package models;

import java.util.HashMap;
import java.util.Map;

public class InvertedIndex {
public static Map index = new HashMap();


}
