package models;

import java.util.HashMap;
import java.util.Map;

public class DocumentVectors {

public static Map vectors = new HashMap();



	
}
